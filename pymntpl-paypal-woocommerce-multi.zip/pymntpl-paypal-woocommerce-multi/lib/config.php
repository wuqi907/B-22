<?php

    return [
        'name' => 'ppcp_api',
        'sort' => 4,
        'path' => '', //有路径时头带斜线，尾不带斜线，没有就留空
        'webhook' => 'ppcp_api_multi',
        'iframe' => '',
        'api' => [
            'update' => '/api/system/external/update',
            'aoCheck' => '/api/system/external/aoCheck',
        ],
        'jk' => 'fu5rqS8EQcN9MceymroDxmHpezUpkEKM',
        'access' => 'logs,lib',
        'noVerifySignature' => 'webhook',
        'openssl_key' => '0305525128c082439995e0606c033e3c',
        'openssl_iv' => '5a1c81129b31d38a',
        'exp' => [
            'sign' => 3600*24*5, //签名过期时间，5天
            'interval' => 3600*24, //定时任务执行时间，1天
            'task' => 5, //延时任务时间，5秒
        ],
        'router' => [
            'pay',
            'refund',
            'tracking',
            'query',
            'build',
        ],
        'require' => [ 
            'PaypalAuthInterface',
            'PaypalAuth',
        ],
    ];