<?php

class WebhookNotice extends PaypalAuth {
    
    public function catchWebhook()
    {
        try {
            $payload = file_get_contents('php://input');
            if(!$this->checkHeaders()) throw new \Exception('invalid headers');
            
            if(!$this->checkSign($payload)) throw new \Exception('sign check failed');
            
            $payload = json_decode($payload);
            if(!empty($payload->resource->custom_id)) $this->handlerWebhook($payload->event_type, $payload->resource);
        } catch (\Exception $e) {
            $this->setErrorMsg($e->getMessage());
            return false;
        }
        
        return 'ok';
    }
    
    private function checkHeaders() {
		$headers = [
			'HTTP_PAYPAL_TRANSMISSION_SIG',
			'HTTP_PAYPAL_AUTH_ALGO',
			'HTTP_PAYPAL_CERT_URL',
			'HTTP_PAYPAL_TRANSMISSION_ID',
			'HTTP_PAYPAL_TRANSMISSION_TIME'
		];
		
		foreach($headers as $header) {
			if(empty($_SERVER[ $header ])) return false;
		}
		
		return true;
	}
    
    //处理webhook
    public function handlerWebhook($type, $object)
	{
	    $ref = xtMultiSn($object->custom_id);
		 
	    $postData = [];
	    switch($type) {
	        case 'PAYMENT.CAPTURE.COMPLETED':
	             $postData = [
                    'order_id' => $ref->order_id, 
                    'payment_id' => $object->id ?? '',
                    'code' => 2, 
                ];
                
                xtCacheOrder(['status' => 'complete'], $object->custom_id);
	            break;
	        case 'PAYMENT.CAPTURE.PENDING':
	            $postData = [
                    'order_id' => $ref->order_id, 
                    'fail_msg' => 'pending'
                ];
	            break;
	        case 'PAYMENT.CAPTURE.DENIED':
	            $postData = [
                    'order_id' => $ref->order_id, 
                    'code' => 3, 
                    'fail_msg' => 'denied'
                ];
	            break;
	        case 'PAYMENT.AUTHORIZATION.VOIDED':
            case 'PAYMENT.AUTHORIZATION.EXPIRED':
                $postData = [
                    'order_id' => $ref->order_id,
                    'refund_code' => 2,
                    'fail_msg' => $type
                ];
                break;
	        case 'PAYMENT.CAPTURE.REFUNDED':
	            $status = $object->state == 'COMPLETED';
	            $postData = [
                    'order_id' => $ref->order_id,
                    'refund_id' => $status ? $object->id : '',
                    'refund_code' => $status ? 2 : 3,
                ];
	            break;
	       // case 'CUSTOMER.DISPUTE.CREATED':
	       //     $postData = [
	       //         'order_id' => $ref->order_id,
	       //         'dispute_code' => 1
	       //     ];
	       //     break;
	       // case 'CUSTOMER.DISPUTE.RESOLVED':
	       //     $postData = [
	       //         'order_id' => $ref->order_id,
	       //         'dispute_code' => $object->status == 'RESOLVED' ? 2 : 3
	       //     ];
	       //     break;
	    }
	  
	    if(!empty($postData)) {
            if($ref->terminal) {
                $postData['response'] = json_encode($object);
                $this->orderNotice($object->custom_id, $postData);
            } else {
                if(!empty($postData['code'])) {
                    $order = wc_get_order($ref->order_id);
                    if(empty($order)) return;
                    
                    $status = $postData['code'] === 2;
                    if($order->get_status() != 'completed') {
                        $order->update_status($status ? 'completed' : 'failed');
                        if($status) $order->set_transaction_id($object->id);
                        $order->save();
                    }
                }
            }
	    }
	}
}