<?php

class IframeCheckout extends PaypalAuth {
    
    public function checkout() 
    {
        try {
            header("Referrer-Policy: no-referrer");
            header("Cache-Control: no-cache, no-store, must-revalidate");
            header("Pragma: no-cache");
            header("Expires: 0");
            header('Content-Type: text/html; charset=utf-8');
            
            $request = new \xt\plus\Request();
            if($request->isPost()) {
                //if(!$request->checkSign()) throw new \Exception('invalid sign');
                
                if(!$this->checkToken()) throw new \Exception('invalid token');
                
                if(empty($_POST)) throw new \Exception('invalid params');
                
                $encodeSsl = xtCache($_POST['token']); 
        	    if(empty($encodeSsl)) throw new \Exception('invalid data');
        	    
        	    $params = xtParseQueryParams(\xt\plus\Util::decode($encodeSsl));
        	    $order = xtCache('order'.$params['terminal'].$params['order_id']);
        	    if(empty($order) || empty(get_object_vars($order))) throw new \Exception('invalid order');
        	    
        	    if(empty($order->check_ip)) {
        	        $order->check_ip = xtIp();
        	        xtCacheOrder(['check_ip' => xtIp()], $order);
        	    }
        	    
        	    if(!empty($order->status) && $order->status == 'completed') throw new \Exception('order was completed');
        	    
        	    $order->checkout_info = $_POST;
                $result = $this->payment($order);
                if($result === false) throw new \Exception($this->getErrorMsg());
                
                xtSuccess('', ['url' => $result]);
            }
            
            if(empty($_SERVER['HTTP_REFERER'])) {
                http_response_code(404);
                exit;
            }
            
            $fields = [
                'assets' => WC_ADYEN_PLUGIN_ASSEET,
                'sign' => $request->getAuthorization(),
                'iframe_id' => '#'.xtConfig('name').'-iframe'
            ];
            
            $keys = array_keys($fields);
            $content = file_get_contents(WC_ADYEN_PLUGIN_PATH.'/checkout/card.php');
            foreach($keys as $k) {
                $content = str_replace('{{'.$k.'}}', $fields[$k], $content);
            }
            
            die($content);
        } catch (\Exception $e) {
            xtFail($e->getMessage());
        }
    }
    
    private function checkToken()
    {
        try {
            $visit = xtDomain().$_SERVER['REQUEST_URI'];
            $params = array_merge(parse_url($visit), xtParseQueryParams($visit)); 
            $signContent = xtConfig('base').xtDomain().$params['path'].'?timestamp='.$params['timestamp'].xtConfig('jk');
            
            //if(time() > (intval($params['timestamp']) + intval(xtConfig('exp.order')))) throw new \Exception('timeout');
            return md5($signContent) === $params['token'];
        } catch (\Exception $e) {
            return false;
        }
    }
}