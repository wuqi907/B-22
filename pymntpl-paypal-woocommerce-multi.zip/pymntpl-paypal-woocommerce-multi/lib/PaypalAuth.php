<?php

use \xt\multi\Util;

class PaypalAuth extends Util
{
    use \xt\multi\Common;
    
    private $order;
    
    public function __construct()
    {
        parent::__construct();
    }
    
    private function payment() {
        $available_gateways = WC()->payment_gateways->get_available_payment_gateways();
        if(!isset($available_gateways['ppcp_api'])) throw new \Exception('payment mismatch');
        
        return $available_gateways['ppcp_api'];
    }
    
    public function create($order)
    {
        try {
            $this->order = $order;
            $this->order->terminal_order_sn = xtMultiSn($this->order);
            
            $this->encodeUrl();
            
            $response = $this->payment()->process_payment($this->getBody());
            if(empty($response) || empty($response->paypal_order) || empty($response->paypal_order->id)) throw new \Exception('create order failed');
            
            $response = $response->paypal_order;
            
            $postData = [
                'order_id' => $this->order->id,
                'session_id' => $response->id,
                'response' => json_encode($response),
                'request' => json_encode($this->order),
            ];
            
            $this->orderNotice($this->order->terminal_order_sn, $postData);
            
            return $this->encodeUrl($response);
        } catch(\Exception $e) {
            $this->setErrorMsg($e->getMessage());
            $this->errorNotice($this->order->terminal_order_sn, $e->getMessage());
            return false;
        }
    }
    
    public function getBody()
    {
        // $query = new WC_Order_Query([
        //     'limit' => 1,         
        //     'orderby' => 'rand', 
        //     'return' => 'ids', 
        // ]);
        
        // $wcOrderIds = $query->get_orders();
        // $wcOrder = empty($wcOrderIds) ? wc_create_order() : wc_get_order($wcOrderIds[0]);
        // $order = clone $wcOrder;
        // if(empty($wcOrderIds)) $wcOrder->delete(true);
        
        // $order->set_id($this->order->id);
        // $order->set_status('pending');
        // $order->set_currency($this->order->currency);
        // $order->set_total($this->order->order_money);
        
        
        // $order->set_billing_first_name($this->order->billing->first_name ?? '');
        // $order->set_billing_last_name($this->order->billing->last_name ?? '');
        // $order->set_billing_address_1($this->order->billing->address_1 ?? '');
        // $order->set_billing_address_2($this->order->billing->address_2 ?? '');
        // $order->set_billing_city($this->order->billing->city ?? '');
        // $order->set_billing_state($this->order->billing->state ?? '');
        // $order->set_billing_postcode($this->order->billing->zip ?? '');
        // $order->set_billing_country($this->order->billing->country ?? '');
        // $order->set_billing_email($this->order->billing->email ?? '');
        // $order->set_billing_phone($this->order->billing->phone ?? '');
    
        // $order->set_billing_first_name($this->order->shipping->first_name ?? '');
        // $order->set_shipping_last_name($this->order->shipping->last_name ?? '');
        // $order->set_shipping_address_1($this->order->shipping->address_1 ?? '');
        // $order->set_shipping_address_2($this->order->shipping->address_2 ?? '');
        // $order->set_shipping_city($this->order->shipping->city ?? '');
        // $order->set_shipping_state($this->order->shipping->state ?? '');
        // $order->set_shipping_postcode($this->order->shipping->zip ?? '');
        // $order->set_shipping_country($this->order->shipping->country ?? '');
        // $order->set_shipping_phone($this->order->shipping->phone ?? '');
        
        // $order->terminal = $this->order->terminal;
        // $order->from_domian = $this->order->from_domain;
        // $order->domain = $this->order->domain;
        // $order->ip = $this->order->ip;
        // $order->terminal_order_sn = $this->order->terminal_order_sn;
        // $order->success_url = $this->order->success_url;
        // $order->cancel_url = $this->order->cancel_url;
        
        // return $order;
        
        $order = wc_create_order();
        
        $order->set_status('pending');
        $order->set_currency($this->order->currency);
        $order->set_total($this->order->order_money);
        
        $order->set_billing_first_name($this->order->billing->first_name ?? '');
        $order->set_billing_last_name($this->order->billing->last_name ?? '');
        $order->set_billing_address_1($this->order->billing->address_1 ?? '');
        $order->set_billing_address_2($this->order->billing->address_2 ?? '');
        $order->set_billing_city($this->order->billing->city ?? '');
        $order->set_billing_state($this->order->billing->state ?? '');
        $order->set_billing_postcode($this->order->billing->zip ?? '');
        $order->set_billing_country($this->order->billing->country ?? '');
        $order->set_billing_email($this->order->billing->email ?? '');
        $order->set_billing_phone($this->order->billing->phone ?? '');
    
        $order->set_shipping_first_name($this->order->shipping->first_name ?? '');
        $order->set_shipping_last_name($this->order->shipping->last_name ?? '');
        $order->set_shipping_address_1($this->order->shipping->address_1 ?? '');
        $order->set_shipping_address_2($this->order->shipping->address_2 ?? '');
        $order->set_shipping_city($this->order->shipping->city ?? '');
        $order->set_shipping_state($this->order->shipping->state ?? '');
        $order->set_shipping_postcode($this->order->shipping->zip ?? '');
        $order->set_shipping_country($this->order->shipping->country ?? '');
        $order->set_shipping_phone($this->order->shipping->phone ?? '');
        $order->set_payment_method('ppcp_api');
        
        $order->terminal = $this->order->terminal;
        $order->from_domian = $this->order->from_domain;
        $order->domain = $this->order->domain;
        $order->ip = $this->order->ip;
        $order->terminal_order_sn = $this->order->terminal_order_sn;
        $order->success_url = $this->order->success_url;
        $order->cancel_url = $this->order->cancel_url;
        
        $wpOrder = wc_get_order($order->get_id());
        $wpOrder->delete(true);
        
        $order->set_id($this->order->id);
        
        return $order;
    }
    
    private function encodeUrl($response = null)
    {
        if($response) {
            $this->order->checkout_url = $this->cardPayment($response->links);
            $this->order->checkout_id = $response->id;
            xtValidOrder($this->order->terminal_order_sn, $this->order);
            
            return ['url' => $this->order->payment_url, 'session_id' => $response->id, 'terminal_order_sn' => $this->order->terminal_order_sn];
        }
        
        $urls = ['payment_url', 'success_url', 'cancel_url'];
        foreach($urls as $key => $u) {
            $encodeUrl = $this->encode(xtCallbackUrl($this->order->terminal_order_sn, lcfirst(get_class($this)) ,$key));
            $this->order->{$u} = $this->validToken(null, __FILE__,  $encodeUrl);
        }
    }
    
    //成功
    public function success($order)
    {
        $this->order = $order;
        
        try {
            $_POST["ppcp_api_paypal_order_id"] = $this->order->checkout_id;
            $_POST["ppcp_api_billing_token"]   = null;
            
            $response = $this->payment()->process_payment($this->getBody());
            if(empty($response) || empty($response->paypal_order) || empty($response->paypal_order->id)) throw new \Exception('query order failed');
            
            $response = $response->paypal_order;
            $status = $response->status == 'COMPLETED';
            
            if($status && empty($this->order->query_order)) xtCacheOrder(['status' => 'completed'], $this->order);
            
            if($this->order->terminal) {
                $postData['order_id'] = $this->order->id; 
                $postData['payment_id'] = $status ? $response->purchase_units[0]['payments']['captures'][0]['id'] : '';
                $postData['code'] = $status ? 2 : 3;
                $postData['response'] = json_encode($response); 
                
                if(!empty($this->order->query_order)) {
                    $postData['code'] = $postData['code'] === 3 ? 1 : $postData['code'];
                    return $postData;
                }
                
                $url = $this->orderNotice($this->order->terminal_order_sn, $postData, true);
            } else {
                $order = wc_get_order($this->order->id);
                if(empty($order)) throw new \Exception('invilid order'); 
                
                if($order->get_status() != 'completed') {
                    
                    $order->update_status($status ? 'completed' : 'failed');
                    if($status) $order->set_transaction_id($response->purchase_units[0]['payments']['captures'][0]['id']);
                    $order->save();
                }
                $url = $order->get_checkout_order_received_url();
            }
        } catch (\Exception $e) {
            $this->setErrorMsg($e->getMessage());
            $this->errorNotice($this->order->terminal_order_sn, $e->getMessage());
            return false;
        }
        
        return $url;
    }
    
    //取消
    public function cancel($order) 
    {
        try {
            if($order->terminal) {
                $postData['order_id'] = $order->id;
                $postData['fail_msg'] = 'Cancel The Payment';
            
                $url = $this->orderNotice($order->terminal_order_sn, $postData, true);
            } else {
                $order = wc_get_order($order->id);
                if(empty($order)) throw new \Exception('invilid order'); 
                
                if($order->get_status() != 'completed') {
                    $order->update_status('failed');
                    $order->save();
                }
                
                $url = $order->get_checkout_order_received_url();
            }
        } catch (\Exception $e) {
            $this->setErrorMsg($e->getMessage());
            $this->errorNotice($order->terminal_order_sn, $e->getMessage());
            return false;
        }
        
        return $url;
    }
    
    //卡支付、收银台
    private function cardPayment($links) 
	{
	    $url = '';
	    foreach($links as $value) {
	        if($value['rel'] == 'approve') {
	            $url = $value['href'];
	        }
	    }
	    
	    if(empty($url)) throw new \Exception('payment link not exists');
	    
	    if($this->order->payment->method == 1) return $url;
	    
	    $parse = parse_url($url);
        return $parse['scheme'].'://'.$parse['host'].'/checkoutweb/signup?'.$parse['query'].'&country.x='.$this->order->billing->country;
	}
    
    //物流
    public function tracking($trackingData)
    {
        $data = [
            'transaction_id' => $trackingData->order_cid,
            'tracking' => $trackingData->trackers->tracking_number,
            'shipping_status' => $trackingData->trackers->status,
            'carrier' => $trackingData->trackers->carrier,
            'carrier_other' => '',
            'notify_buyer' => false,
            'terminal' => $trackingData->terminal,
        ];
        
        $tracking = new \PaymentPlugins\WooCommerce\PPCP\Rest\Routes\Admin\AdminOrderTracking($this->payment()->payment_handler->client);
        $result = $tracking->handle_sipping($data);
        if(empty($result) || $result->code != 200) throw new \Exception('request tracking failed');
        
        return ['tracking_info' => $result->msg];
    }
    
    //退款
    public function refund($refundData)
    {
        try {
            $result = $this->payment()->process_refund($refundData, $refundData->amount);
            if(empty($result) || empty($result->id)) throw new \Exception('refund request failed');
            
            $status = isset($result['status']) && $result['status'] == 'COMPLETED';
            
            $result = [
                'code' => $status ? 8 : 9,
                'order_id' => $refundData->order_id,
                'refund_id' => $status ? $result->id : '',
                'response' => json_encode($result) 
            ];
            
        } catch(\Exception $e) {
            $this->setErrorMsg($e->getMessage());
            return false;
        }
        
        return $result;
    }
    
    //订单查询
    public function query($queryData) {
        try {
            $queryData->query_order = 1;
            $terminal_order_sn = getRef($queryData->terminal_order_sn);
            $queryData->id = $terminal_order_sn->order_id;
            $queryData->terminal = $terminal_order_sn->terminal;
            $result = $this->success($queryData);
            if(empty($result)) throw new \Exception('query checkout_id order failed');
            
            return $result;
        } catch (\Exception $e) {
            $this->setErrorMsg($e->getMessage());
            $this->errorNotice($queryData->terminal_order_sn, $e->getMessage());
            return false;
        }
    }
    
    public function checkSign($payload) 
    {
        $payload = json_decode($payload, true);
        $env = $this->payment()->settings['environment'];
        $params = [
			'auth_algo'         => isset( $_SERVER['HTTP_PAYPAL_AUTH_ALGO'] ) ? $_SERVER['HTTP_PAYPAL_AUTH_ALGO'] : '',
			'cert_url'          => isset( $_SERVER['HTTP_PAYPAL_CERT_URL'] ) ? $_SERVER['HTTP_PAYPAL_CERT_URL'] : '',
			'transmission_id'   => isset( $_SERVER['HTTP_PAYPAL_TRANSMISSION_ID'] ) ? $_SERVER['HTTP_PAYPAL_TRANSMISSION_ID'] : '',
			'transmission_sig'  => isset( $_SERVER['HTTP_PAYPAL_TRANSMISSION_SIG'] ) ? $_SERVER['HTTP_PAYPAL_TRANSMISSION_SIG'] : '',
			'transmission_time' => isset( $_SERVER['HTTP_PAYPAL_TRANSMISSION_TIME'] ) ? $_SERVER['HTTP_PAYPAL_TRANSMISSION_TIME'] : '',
			'webhook_id'        => $this->payment()->settings['webhook_id_'.$env],
			'webhook_event'     => $payload
		];
		
        $result = $this->payment()->payment_handler->client->environment($env)->webhooks->verifySignature($params);
        
        return $result->verification_status === 'SUCCESS';
    }
}