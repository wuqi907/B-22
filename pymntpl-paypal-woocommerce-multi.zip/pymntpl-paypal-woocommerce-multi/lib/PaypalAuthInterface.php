<?php

class PaypalAuthInterface
{
    use \xt\multi\Common;
    
    private $data;
    private $payment;
    
    public function __construct($data) 
    {
        try {
            $this->data = $data;
             
            $this->payment = new PaypalAuth();
        } catch (\Exceptioin $e) {
            $this->setErrorMsg($e->getMessage());
        }
    }
    
    public function pay()
    {
        try {
            $result = $this->payment->create($this->data);
            if($result === false) throw new \Exception($this->payment->getErrorMsg());
            
        } catch(\Exception $e) {
            $this->setErrorMsg($e->getMessage());
            return false;
        }
        
        return $result;
    }
    
    public function refund() {
        try {
            $result = $this->payment->refund($this->data);
            if($result === false) throw new \Exception($this->payment->getErrorMsg());
            
        } catch(\Exception $e) {
            $this->setErrorMsg($e->getMessage());
            return false;
        }
        
        return $result;
    }
    
    public function tracking() 
    {
        try {
            $result = $this->payment->tracking($this->data);
            if($result === false) throw new \Exception($this->payment->getErrorMsg());
            
        } catch(\Exception $e) {
            $this->setErrorMsg($e->getMessage());
            return false;
        }
        
        return $result;
    }
    
    public function query() 
    {
        try {
            $result = $this->payment->query($this->data);
            if($result === false) throw new \Exception($this->payment->getErrorMsg());
            
        } catch(\Exception $e) {
            $this->setErrorMsg($e->getMessage());
            return false;
        }
        
        return $result;
    }
    
    public function build()
    {
        try {
            $result = $this->payment->buildOrder($this->data);
            if($result === false) throw new \Exception('build order failed');
            
        } catch(\Exception $e) {
            $this->setErrorMsg($e->getMessage());
            return false;
        }
        
        return $result;
    }
}