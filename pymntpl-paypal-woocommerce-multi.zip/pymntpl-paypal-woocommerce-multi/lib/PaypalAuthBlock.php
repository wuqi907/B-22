<?php

use \Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

class PaypalAuthBlock extends AbstractPaymentMethodType
{
    public $util;
    
    public $settings;
    
    private $gateway;
    
    public $name;
    
    public function initialize()
    {
        $gateways = WC()->payment_gateways->payment_gateways();
        
        $this->gateway = $gateways[$this->name];
    }
    
    public function is_active()
    {
        return $this->gateway->is_available();
    }
    
    public function get_payment_method_script_handles()
    {
		$script_asset      = [
		    'dependencies' => array(),  //'react', 'wc-blocks-registry', 'wc-settings', 'wp-html-entities', 'wp-i18n', 'wp-blocks', 'wp-components', 'wp-element'
			'version'      => time()
		];
		$script_url        = plugins_url('/assets', __DIR__).'/js/block.js';
		
        $blockname = $this->name.'-blocks';
		wp_register_script(
			$blockname,
			$script_url,
			$script_asset[ 'dependencies' ],
			$script_asset[ 'version' ],
			true
		);

		return [$blockname];
    }
    
    public function get_payment_method_data() 
    {
		return [
			'title'       => $this->get_setting('title'),
			'description' => $this->get_setting('description'),
			'iframe_url'  => ''
		];
	}
}