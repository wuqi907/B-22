<?php
namespace xt\multi;

class AsyncTask
{
    public function handlerUpdateClientTask($data)
    {
        if(!empty($data['task_name'])) {
            
            $class = ucfirst($data['task_name']);
            $class = '\\xt\\multi\\'.$class;
           
            if(!class_exists($class)) return;
            
            $task = new $class();
            if(!method_exists($task, $data['action'])) return;
            
            $task->{$data['action']}($data['data']);
            
            return;    
        }
       
        if($data['order_task'] === true) {
            $this->handlerUdpateOrderTask($data);
            return;
        }
     
        $this->handlerNoticeClientTask($data);   
    }
    
    private function handlerUdpateOrderTask($updateData)
    {
        $postData = [
            'order_id' => $updateData['order_id'],    
            'build_status' => 'failed',
            'interface' => 'build',
        ];
        
        //1=包含订单跟商品，2=订单（不包含商品），3=商品（不包含订单）
        switch($updateData['type']) {
            case 1:
                $id = xtCreateOrder($updateData);
                if($id) {
                    $postData['c_id'] = $id;
                    $postData['build_status'] = 'successed';
                }
                break;
            case 2:
                $id = xtCreateOrder($updateData, false);
                if($id) {
                    $postData['c_id'] = $id;
                    $postData['build_status'] = 'successed';
                }
                break;
            case 3:
                $id = xtCreateGoods($updateData, (new ProductsCsv())->randGoods());
                if($id) {
                    $postData['p_id'] = $id;
                    $postData['build_status'] = 'successed';
                }
                break;
            default:
                return;
        }
        
        $postData = array_merge($postData, $updateData);
        $this->handlerNoticeClientTask($postData);
    }
    
    private function handlerNoticeClientTask($updateData) 
    {
        $res = (new Request())->post($updateData['api'], json_encode($updateData));
        if(empty($res) || $res->code != 200) (new Util())->task($updateData);
    }
}














