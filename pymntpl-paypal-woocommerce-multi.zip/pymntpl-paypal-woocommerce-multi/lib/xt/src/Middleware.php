<?php
namespace xt\multi;

class Middleware {
    
    public function __construct()
    {
        $request = new Request();
        try {
            if(!$request->checkPath()) {
                 header("HTTP/1.1 404 Not Found");
                 exit;
            }
            
            if($request->isVerifySystem() && $request->noVerifySignature() && $request->isPost() && !$request->checkSign()) throw new \Exception('Signature verification failed');
            
        } catch(\Exception $e) {
            http_response_code(500);
            die($e->getMessage());
        }
    }
    
    public static function init()
    {
        new self();
    }
}