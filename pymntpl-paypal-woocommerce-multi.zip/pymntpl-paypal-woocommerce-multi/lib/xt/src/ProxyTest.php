<?php

namespace xt\multi;

class ProxyTest
{
    private $setting;
    
    private $paymentName;
    
    public function __construct($paymentName)
    {
        $this->paymentName = $paymentName;
        $this->setting = get_option('woocommerce_'.$this->paymentName.'_settings');
    }
    
    public function test()
    {
        $header = [
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36',
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1');
        curl_setopt($ch, CURLOPT_PROXY, 'socks5://'.$this->setting['proxy_address']);
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $this->setting['proxy_account'].':'.$this->setting['proxy_password']);
        curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        $res = curl_exec($ch);
    
        if(empty($res)) throw new \Exception(curl_error($ch));
        
        $res = json_decode($res);
        if(empty($res->error) || empty($res->error->message)) throw new \Exception('test api request failed');
        
        curl_close($ch);
    }
}