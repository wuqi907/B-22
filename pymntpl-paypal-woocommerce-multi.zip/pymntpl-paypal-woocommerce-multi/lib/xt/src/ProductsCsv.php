<?php
namespace xt\multi;

class ProductsCsv {
    public function chunkProducts() 
    {
        $args = [
            'status' => 'publish',
            'limit' => 500,
            'return' => 'ids'
        ];
        
        $ids = wc_get_products($args) ?? [];
        
        if(count($ids)) {
            $chunk = array_chunk($ids, 200);
            foreach($chunk as $v) {
                $taskData = [
                    'task_name' => 'productsCsv',
                    'action' => 'buildCsv',
                    'data' => $v
                ];
                
                as_enqueue_async_action('updateClientTask', [$taskData]);
            }
        }
    }
    
    public function csvDir()
    {
        return xtCacheDir().'/product';
    }
    
    public function csvFile()
    {
        return $this->csvDir().'/product.csv';
    }
    
    public function isCsvExists() 
    {
        return file_exists($this->csvFile());
    }
    
    public function buildCsv($ids = [])
    {
        $prodcuts = wc_get_products(['include' => $ids, 'limit' => -1]);
        $out = '';
        foreach($prodcuts as $item) {
            $row = [];
            $row = [
                $item->get_name(),  //产品名称
                str_replace("\n", '', $item->get_description()), //产品详情htmlentities()
                xtGoodsImage($item->get_id()),  //产品图片
                implode(',', xtGoodsCategory($item->get_id())), //产品分类
                $item->get_sku(), //产品规格
            ];
            
            $out .= implode('--||--', $row)."\n";
        }
        
        if(!is_dir($this->csvDir())) mkdir($this->csvDir(), 0755, true);
        
        file_put_contents($this->csvFile(), $out, FILE_APPEND | LOCK_EX);
    }
    
    public function randGoods() 
    {
        try {
            if(!$this->isCsvExists()) {
                xtProductCacheTask();
                throw new \Exception('not csv cache');
            }
        
            $lines = file($this->csvFile());
            if(!$lines) throw new \Exception('random line read failed');
            
            $line = $lines[array_rand($lines)];
            $line = explode('--||--', $line);
            
            $product = [
                'name' => $line[0],
                'desc' => $line[1],
                'image' => $line[2],
                'category' => explode(',', $line[3]),
                'sku' => $line[4],
            ];
            
            return $product;
        } catch (\Exception $e) {
            $goods = xtRandGoods();
            $goods = wc_get_product($goods->ID);
            $product = [
                'name' => $goods->get_name() ?: '',
                'desc' => str_replace("\n", '', $goods->get_description()) ?: '',
                'image' => xtGoodsImage($goods->get_id()) ?: '',
                'category' => xtGoodsCategory($goods->get_id()) ?: [],
                'sku' => $goods->get_sku() ?: '', 
            ];
            
            return $product;
        }
    }
}