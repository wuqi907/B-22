<?php
namespace xt\multi;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\SignatureInvalidException;

class Request {
    use Base;
    
    public $alg = 'HS512';
    
    public function post($url, $postData, $header = null, $ext = [])
    {
        if(!$header) {
            $header[] = 'Accept:application/json';
            $header[] = 'Content-Type:application/json';
        }
        
        if(!empty($ext) && is_array($ext)) {
            foreach($ext as $v) {
                $header[] = $v;
            }
        }
        
        $header[] = 'Authorization-Xt:'.$this->getAuthorization();
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
        $res = curl_exec($ch);
        curl_close($ch);
        return json_decode($res);
    }
    
    public function getAuthorization($flag = true)
    {
        $data = [
            'iat' => time(),
            'exp' => time()+intval($this->config('exp.sign'))
        ];
        
        if($flag === true) {
            $data['iss'] = xtDomain();
            $data['aud'] = $this->config('base');
        }
        
        return JWT::encode($data, $this->config('jk'), $this->alg);
    }
    
    public function checkSign()
    {
        $authorization = $_SERVER['HTTP_AUTHORIZATION_XT'] ?? '';
        if(empty($authorization) || count($parts = explode('.', $authorization)) != 3) return false;
        
        try {
            return JWT::decode($authorization, new Key($this->config('jk'), $this->alg));
        } catch(SignatureInvalidException $e) {
            return false;
        } catch(Exception $e) {
            return false;
        }
    }
    
    public function checkPath()
    {
        $path = explode(',', $this->config('access'));
        foreach($path as $v) {
            if(strpos($_SERVER['REQUEST_URI'], $v) !== false) return false;
        }
        return true;
    }
    
    public function noVerifySignature()
    {
        $noVerifySignature = $this->config('noVerifySignature');
        $noVerifySignature = str_replace(' ', '', $noVerifySignature);
        if(!$noVerifySignature) return true;
        
        $noVerifySignature = explode(',', $noVerifySignature);
        foreach($noVerifySignature as $v) {
            if(strpos($_SERVER['REQUEST_URI'], $v) !== false) return false;
        }
        return true;
    }
    
    public function isVerifySystem()
    {
        return !function_exists('get_bloginfo');
    }
    
    public function isPost()
    {
        return $_SERVER['REQUEST_METHOD'] === 'POST';
    }
    
    public function isGet()
    {
        return $_SERVER['REQUEST_METHOD'] === 'GET';
    }
}