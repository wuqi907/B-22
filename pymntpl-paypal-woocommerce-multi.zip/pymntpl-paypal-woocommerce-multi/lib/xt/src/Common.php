<?php
namespace xt\multi;

trait Common {
    
    private $errorMsg;
    
    public function setErrorMsg($msg = '')
    {
        $this->errorMsg = $msg;
    }
    
    public function getErrorMsg()
    {
        return $this->errorMsg;
    }
    
    public function validateCard($key, $value) 
    {
        $fields = [
            'woo-card-number' => function($value) {
                try {
                    $number = str_replace(' ', '', $value);
                    if(!preg_match('/^\d{13,19}$/', $number)) throw new \Exception('Invalid Card Number Char. ');
                    
                    $sum = 0;
                    $alt = false;
                
                    for ($i = strlen($number) - 1; $i >= 0; $i--) {
                        $n = (int)$number[$i];
                        if ($alt) {
                            $n *= 2;
                            if ($n > 9) {
                                $n -= 9;
                            }
                        }
                        $sum += $n;
                        $alt = !$alt;
                    }
                
                    if(!($sum % 10 == 0)) throw new \Exception('Invalid Card Number. ');
                } catch (\Exception $e) {
                    return $e->getMessage();
                }
                
                return '';
            },
            'woo-card-expiry' => function($value) {
                try {
                    $arr = explode('/', $value);
                    if(!is_array($arr) || count($arr) != 2) throw new \Exception('Invalid Card Expiry Char. ');
                    
                    $year = $arr[1];
                    $month = $arr[0];
                    
                    if(!preg_match('/^\d{2}$/', $month) || !preg_match('/^\d{2}$/', $year)) throw new \Exception('Invalid Card Expiry Month / Year. ');
                    
                    if(intval($month) < 1 || intval($month) > 12) throw new \Exception('Invalid Card Expiry Month. ');
                    
                    
                    $currentYear = date('y');
                    $currentMonth = date('m');
                
                    if ($year < $currentYear || ($year == $currentYear && intval($month) < intval($currentMonth))) throw new \Exception('Invalid Card Expiry Date. ');
                    
                } catch (\Exception $e) {
                    return $e->getMessage();
                }
                
                return '';
            },
            'woo-card-cvc' => function($value) {
                try {
                     if(!preg_match('/^\d{3,4}$/', $value)) throw new \Exception('Invalid Card CVC. ');
                } catch (\Exception $e) {
                    return $e->getMessage();
                }
                
                return '';
            }
        ];
        
        if(isset($fields[$key])) return $fields[$key]($value);
        
        throw new \Exception('Invalid Params');
    }
    
    public function getCardValidateMsg(&$order) 
    {
        $keys = array_keys($order->checkout_info);
        $msg = '';
        foreach($keys as $k => $value) {
            $order->checkout_info[$value] = str_replace(' ', '', $order->checkout_info[$value]);
            if(in_array($value, ['woo-card-number', 'woo-card-expiry', 'woo-card-cvc'])) $msg .= $this->validateCard($value, $order->checkout_info[$value]);
        }
        
        return $msg;
    }
    
    public function cardInfo($order, $isAllYear = false) 
    {
        $expiry = explode('/', $order->checkout_info['woo-card-expiry']);
            
        $card = new \stdClass();
        $card->holder_name = $order->billing->first_name.' '.$order->billing->last_name;
        $card->number = $order->checkout_info['woo-card-number'];
        $card->month = $expiry[0];
        $card->cvv = $order->checkout_info['woo-card-cvc'];
        $card->expiry = $order->checkout_info['woo-card-expiry'];
        $card->year = $isAllYear === true ? substr(date('Y'), 0, 2).$expiry[1] : $expiry[1];
        
        return $card;
    }
}