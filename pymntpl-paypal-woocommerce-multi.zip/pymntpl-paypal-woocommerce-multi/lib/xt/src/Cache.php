<?php
namespace xt\multi;

use Phpfastcache\CacheManager;
use Phpfastcache\Config\ConfigurationOption;

class Cache {
    
    private $cacheDir;
    private $cache;
    private static $instance = null;
    
    public function __construct() 
    {
        $this->cacheDir = xtCacheDir().'/order';
        $this->cache = CacheManager::getInstance('files', new ConfigurationOption([
            'path' => $this->cacheDir,
        ]));
    }
    
    public static function getInstance()
    {
        if(self::$instance === null) self::$instance = new self();
        
        return self::$instance;
    }
    
    public function set($key = '', $value = '', $expiry = '') 
    { 
        if(empty($key) || empty($value)) throw new \Exceptioni('invalid key or value');
        
        $item = $this->cache->getItem($key);
        $item->set($value);
        
        if(is_numeric($expiry)) $item->expiresAfter(intval($expiry));
        
        $this->cache->save($item);
    }
    
    public function append($key = '', $value = '', $expiry = '') 
    {
        if(empty($key) || empty($value)) throw new \Exceptioni('invalid key or value');
        
        $data = $this->get($key);
        $data = $data ? $data : [];
        if(!is_array($data)) throw new \Exception('value is not array');
        
        $data[] = $value;
        $this->set($key, $data, $expiry);
    }
    
    public function get($key = '')
    {
        try {
            if(empty($key)) throw new \Exception('invalid key - 0');
            
            $item = $this->cache->getItem($key);
            if(!$item->isHit()) throw new \Exception('invalid key - 1');
        } catch (\Exception $e) {
            return false;
        }
        
        return $item->get();
    }
    
    public function delete($key = '') 
    {
        if(empty($key)) return ;
        
        $this->cache->deleteItem($key);
    }
    
    public function clear() 
    {
        $this->cache->clear();
    }
    
    public function clearExpired($dir =  '')
    {
        $dir = $dir ?: $this->cacheDir;
        $files = array_diff(scandir($dir), ['.', '..']);
        $currentTime = time();
        foreach ($files as $file) {
            $path = $dir.'/'.$file;
            if(is_dir($path)) {
                $this->clearExpired($path);
                if(count(scandir($path)) === 2) @rmdir($path);
            } else {
                if(strpos($path, '.txt')) {
                    $data = @unserialize(file_get_contents($path)); 
                    $expiry = !empty($data) && isset($data['e']) && !empty($data['e']->date) ? strtotime($data['e']->date) : 0;
                   
                    if(!empty($expiry) && $currentTime > $expiry) @unlink($path);
                }
            }
        }
    }
}