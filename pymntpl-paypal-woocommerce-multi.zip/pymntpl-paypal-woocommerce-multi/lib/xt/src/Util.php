<?php
namespace xt\multi;

class Util {
    
    use Base;
    
    //定义路由
    public function interfaceApi($paymentApi = '') {
        if(empty($paymentApi)) xtError('invalid api');
         
        foreach($this->config('router') as $r) {
	        register_rest_route($paymentApi, '/'.$r, [
    	        'methods' => 'POST',
                'callback' => function(\WP_REST_Request $request) {
                    try {
                        $route = explode('/', trim($request->get_route(), '/'));
                        $data = json_decode(file_get_contents('php://input'));
                         
                        if(empty(get_object_vars($data))) throw new \Exception('invalid params');
                        
                        if(!class_exists($route[0] = ucfirst($route[0]))) throw new \Exception('invalid interface');
                        
                        $data->terminal = rand(1, 9);
                        $interface = new $route[0]($data);
                        
                        if(!method_exists($interface, $route[1])) throw new \Exception('invalid method');
                        
                        $result = $interface->{$route[1]}();
                        if($result === false) xtFail($interface->getErrorMsg());
                        
                        xtSuccess('success', $result);
                    } catch (\Exception $e) {
                        xtError($e->getMessage());
                    }
                },
                'permission_callback' => function() {
                    return (new Request())->checkSign();
                }
    	    ]);
	    }
    }
    
    public function loadBlock($blockClassName = '')
    {
        $blockClassName = ucfirst($blockClassName);
        if(class_exists('\Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
            $blockFile =  $this->baseDir.'/lib/'.$blockClassName.'.php';
            if(!file_exists($blockFile)) return;
            
            require $blockFile;
            
            if(!class_exists($blockClassName)) throw new \Exception('block class not exists');
            
            $blockClass = new $blockClassName();
            $blockClass->util = $this;
            $blockClass->name = $this->basePluginName;
            $blockClass->settings = $this->paymentSettings();
            
			add_action('woocommerce_blocks_payment_method_type_registration', function(\Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry) use($blockClass) {
					$payment_method_registry->register($blockClass);
				}
			);
		}
    }
}
















