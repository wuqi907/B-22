<?php

//处理有效路由
if(!function_exists('xtProcessValidRouter')) {
    function xtProcessValidRouter() {
        if($pluginDir = xtIframe()) {
            $iframeFile = $pluginDir.'/lib/IframeCheckout.php';
            if(!file_exists($iframeFile)) die('missing');
            
            require $iframeFile;
            (new IframeCheckout())->checkout();
        }
        
        if($pluginDir = xtWebhook()) {
            try {
                $webhookFile = $pluginDir.'/lib/WebhookNotice.php';
                if(!file_exists($webhookFile)) throw new \Exception('webhook missing');
                
                require $webhookFile;
                
                $webhookNotice = new WebhookNotice();
                $result = $webhookNotice->catchWebhook();
                if($result === false) throw new \Exception($webhookNotice->getErrorMsg());
                
            } catch(\Exception $e) {
                http_response_code(400);
                die($e->getMessage());
            }
            
            http_response_code(200);
            die($result);
        }
        
        if($token = xtToken()) {
    	    try {
        	    $encodeSsl = xtValidToken($token);
        	    
        	    if(empty($encodeSsl)) throw new \Exception('invalid token');
        	    
        	    $filePath = xtValidToken($token, true);
        	    if(empty($filePath)) throw new \Exception('invalid data');
        	    
        	    $params = xtParseQueryParams((new \xt\multi\Util($filePath))->decode($encodeSsl));
        	    $order = xtValidOrder($params['terminal_order_sn']);
        	    if(empty($order) || empty(get_object_vars($order))) throw new \Exception('invalid order');
        	    
        	    //订单完成重定向
        	    if(!empty($order->status) && $order->status == 'completed') throw new \Exception('order is completed');
        	    
        	    //放行并锁定链接
        	    if(!empty($order->status) && $order->status == 'complete') xtCacheOrder(['status' => 'completed'], $order);
        	    
        	    $class = ucfirst($params['sign']);
        	   
        	    if(!class_exists($class)) throw new \Exception('payment not exists');
        	    
        	    $payment = new $class();
        	    switch($params['query']) {
        	        //官方收银台
        	        case 0:
        	            if(empty($order->check_ip)) xtCacheOrder(['check_ip' => xtIp()], $order);
        	            
        	            $url = $order->checkout_url;
        	            break;
        	        //成功与失败查询
        	        case 1:
        	        case 2:
        	            $action = $params['query'] == 1 ? 'success' : 'cancel';
        	            $url = $payment->{$action}($order);
        	            if(empty($url)) throw new \Exception($payment->getErrorMsg());
        	            
        	            if($order->ip != 'none' && $order->check_ip != xtIp()) throw new \Exception('ip mismatch');
        	            
        	            break;
        	        //自定义
        	        case 3:
        	            if(empty($order->check_ip)) xtCacheOrder(['check_ip' => xtIp()], $order);
        	            
        	            $payment->custom($order);
        	            break;
        	       default:
        	           throw new \Exception('invalid query');
        	    }
        	    
        	    xtLocationReplace($url);
    	    } catch(\Exception $e) {
    	        if(!empty($order->terminal_order_sn) && !empty($filePath)) (new \xt\multi\Util($filePath))->errorNotice($order->terminal_order_sn, $e->getMessage());
    	        
    	        xtLocationReplace(xtDomain());
    	    }
    	}
    }
}

//是否有效路由
if(!function_exists('xtRouter')) {
    function xtRouter($isReturn = null) {
        $uri = $_SERVER['REQUEST_URI'];
        
        if($isReturn === true) return $uri;
        
        if($isReturn === false) return xtDomain().$uri;
        
        $queryLen = strpos($uri, '?');
        if($queryLen !== false) $uri = substr($uri, 0, $queryLen);
        
        return $uri;
    }
}

//有效token
if(!function_exists('xtToken')) {
    function xtToken() {
        $path = xtRouter();
        $len = strrpos($path, '/');
        $token = substr($path, $len+1);
        
        return preg_match('/[a-f0-9]{32}/', $token) ? $token : false;
    }
}

//有效内嵌链接
if(!function_exists('xtIframe')) {
    function xtIframe() {
        return strpos(xtRouter(true), '?') !== false && ($path = xtCache(urlencode(xtDomain().xtRouter()))) ? $path : false;
    }
}

//有效webhook
if(!function_exists('xtWebhook')) {
    function xtWebhook() {
        return xtCache(urlencode(xtDomain().xtRouter()));
    }
}

//解析正真订单号
if(!function_exists('xtGetRef')) {
    function xtGetRef($string) {
        if(empty($string) || strpos($string, '_') === false) throw new \Exception('ref error');
        
        $arr = explode('_', $string);
        $ref = new \stdClass();
        $ref->order_id = $arr[0];
        $ref->terminal = substr($string, -1);
        
        return $ref;
    }
}

//设置多平台唯一订单号
if(!function_exists('xtSetMultiRef')) {
    function xtSetMultiRef($order, $limit = '') {
        $uniqid = uniqid();
        
        if(is_numeric($limit) && is_int($limit)) {
            $uniqidLength = strlen($uniqid);
            $length = strlen($order->id) + strlen($order->terminal) + $uniqidLength + 1;
            
            if($length > $limit) {
                $maxLength = $length - $limit;
                $maxLength = $maxLength > $uniqidLength ? $uniqidLength : $maxLength;
                $uniqid = substr($uniqid, $maxLength);
            }
        }
        $sn = $order->id.'_'.$uniqid.$order->terminal;
        
        xtValidBase($sn, $order->request_domain);
        return $sn;
    }
}

//多平台唯一订单号
if(!function_exists('xtMultiSn')) {
    function xtMultiSn($order, $limit = '', $isEncode = true) {
        if(is_string($order)) {
            $terminalOrderSn = xtTerminalSn($order);
            if(empty($terminalOrderSn) || empty((array) $terminalOrderSn)) throw new \Exception('invalid order sn');
            
            return $terminalOrderSn;
        }
        
        $mid = strtolower(wp_generate_password(12, false));
        $end = uniqid();
        
        if(is_numeric($limit)) {
            $limit = intval($limit);
            $midLength = strlen($mid);
            $length = strlen($order->id) + strlen($order->terminal) + $midLength;
            
            if($length > $limit) {
                $maxLength = $length - $limit;
                if($maxLength > $midLength) throw new \Exception('terminal order sn is too long');
                
                $mid = substr($mid, $maxLength);
                $end = '';
            }
        }
        
        $sn = $order->id.$mid.$order->terminal.$end;
        
        if($isEncode === true) {
            $sn = md5($sn);
            if(is_numeric($limit)) {
                $length = strlen($sn);
                $length = $length > $limit ? $limit : $length;
                $sn = substr($sn, 0, $length);
            }
        }
        
        $realOrderSn = new \stdClass();
        $realOrderSn->order_id = $order->id;
        $realOrderSn->terminal = $order->terminal;
        
        xtTerminalSn($sn, $realOrderSn);
        xtValidBase($sn, $order->request_domain);
        return $sn;
    }
}

//获取商品列表
if(!function_exists('xtProductItems')) {
    function xtProductItems($order) {
        $products = [];
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            $imageUrl = wp_get_attachment_url($product->get_image_id());
            $metaData = $item->get_meta_data();
            $metaArray = [];
            foreach ($metaData as $meta) {
                if(substr($meta->key, 0, 1) == '_') continue;
                
                $metaArray[$meta->key] = $meta->value; 
            }
    
            $meta_serialized = serialize($metaArray);
    
            $itemData = new \stdClass();
            $itemData->post_id = $product->get_id();
            $itemData->post_name = $product->get_name();
            $itemData->price = number_format(round($item->get_total(), 2), 2, '.', '');
            $itemData->quantity = $item->get_quantity();
            $itemData->type = $product->is_type('variation') ? 'variable' : 'simple';
            $itemData->attributes = $meta_serialized;
            $itemData->image = $imageUrl ? $imageUrl : '';
            $itemData->sku = $product->get_sku();
            $itemData->url = $product->get_permalink();
            $itemData->subtotal = number_format(round($item->get_subtotal(), 2), 2, '.', '');
            
            $products[] = $itemData;
        }
        
        return $products;
    }
}

//获取stdclass新订单
if(!function_exists('xtOrder')) {
    function xtOrder($order, $method = '', $method_types = []) {
        $newOrder = new \stdClass();
        	       
        $newOrder->id = $order->id;
        $newOrder->currency = $order->currency;
        $newOrder->order_money = $order->get_total();
        $newOrder->customer_name = $order->get_billing_first_name().' '.$order->get_billing_last_name();
        $newOrder->customer_email = $order->get_billing_email();
        
        $newOrder->billing = new \stdClass();
        $newOrder->billing->address_1 = $order->get_billing_address_1();
        $newOrder->billing->address_2 = $order->get_billing_address_2();
        $newOrder->billing->country = $order->get_billing_country();
        $newOrder->billing->state = $order->get_billing_state();
        $newOrder->billing->city = $order->get_billing_city();
        $newOrder->billing->zip = $order->get_billing_postcode();
        $newOrder->billing->phone = $order->get_billing_phone();
        $newOrder->billing->email = $order->get_billing_email();
        $newOrder->billing->last_name = $order->get_billing_last_name();
        $newOrder->billing->first_name = $order->get_billing_first_name();
        
        $newOrder->shipping = new \stdClass();
        $newOrder->shipping->address_1 = $order->get_shipping_address_1() ? $order->get_shipping_address_1() : $order->get_billing_address_1();
        $newOrder->shipping->address_2 = $order->get_shipping_address_2() ? $order->get_shipping_address_2() : $order->get_billing_address_2();
        $newOrder->shipping->country = $order->get_shipping_country() ? $order->get_shipping_country() : $order->get_billing_country();
        $newOrder->shipping->state = $order->get_shipping_state() ? $order->get_shipping_state() : $order->get_billing_state();
        $newOrder->shipping->city = $order->get_shipping_city() ? $order->get_shipping_city() : $order->get_billing_city();
        $newOrder->shipping->zip = $order->get_shipping_postcode() ? $order->get_shipping_postcode() : $order->get_billing_postcode();
        $newOrder->shipping->phone = $order->get_billing_phone();
        $newOrder->shipping->email = $order->get_billing_email();
        $newOrder->shipping->last_name = $order->get_shipping_last_name() ? $order->get_shipping_last_name() : $order->get_billing_last_name();
        $newOrder->shipping->first_name = $order->get_shipping_first_name() ? $order->get_shipping_first_name() : $order->get_billing_first_name();
        
        $newOrder->from_domain = xtDomain();
        $newOrder->domain = xtDomain();
        $newOrder->ip = $order->get_customer_ip_address();
        $newOrder->request_domain = xtDomain();
        
        $device = $_SERVER['HTTP_WC_ORDER_ATTRIBUTION_DEVICE'] ?? $_POST['wc_order_attribution_device'] ?? '';
        $newOrder->device = !empty($device) ? json_decode(stripslashes($device)) : (new \stdClass());
        $newOrder->device->ua = $_SERVER['HTTP_USER_AGENT'];
        $newOrder->device->ac = $_SERVER['HTTP_ACCEPT'];
        
        $newOrder->payment = new \stdClass();
        $newOrder->payment->method = $method;
        $newOrder->payment->title = 'Woocommerce';
        $newOrder->payment->method_types = $method_types;
        $newOrder->order_product = xtProductItems($order);
        $newOrder->terminal = 0;
        
        return $newOrder;
    }
}

//打印全部参数
if(!function_exists('dd')) {
    function dd($data) {
        echo '<pre>';
        var_dump($data);
        exit;
    }
}

//打印数组
if(!function_exists('dd_r')) {
    function dd_r($data) {
        echo '<pre>';
        print_r($data);
        exit;
    }
}

//记录日志
if(!function_exists('rcd')) {
   function rcd($data = 'test-log', $name = null) {
        $dir = xtCacheDir().'/logs/'.date('Y-m-d');
  
        if(!is_dir($dir)) mkdir($dir, 0777, true);
        
        if(!is_string($data)) $data = json_encode($data);
        
        file_put_contents($dir.'/'.($name ? $name : 'logs').'.log', date('Y-m-d H:i:s').PHP_EOL.$data.PHP_EOL.PHP_EOL, FILE_APPEND | LOCK_EX);
    } 
}

//返回成功
if(!function_exists('xtSuccess')) {
    function xtSuccess($msg = '', $data = []) {
        die(json_encode(['code' => 200, 'data' => $data, 'msg' => $msg]));
    }
}

//返回失败
if(!function_exists('xtFail')) {
    function xtFail($msg = '', $data = []) {
        die(json_encode(['code' => 201, 'data' => $data, 'msg' => $msg]));
    }
}

//返回错误
if(!function_exists('xtError')) {
    function xtError($msg = '', $data= []) {
        die(json_encode(['code' => 401, 'data' => $data, 'msg' => $msg]));
    }
}

//汇率转换
if(!function_exists('xtMoneyRate')) {
    function xtMoneyRate($currency, $rateCurrency = 'USD', $flag = false) {
        try {
            $res = file_get_contents('https://api.exchangerate-api.com/v4/latest/'.$currency);
            $res = json_decode($res, true);
            
            if($flag === true) return $res;
            
            return isset($res['rates']) && count($res['rates']) ? $res['rates'][$rateCurrency] : '';
        } catch (\Exception $e) {
            return '';
        }
    }
}

//获取真实IP
if(!function_exists('xtIp')) {
    function xtIp() {
        $ip = NULL;
        if(isset($_SERVER['HTTP_X_REAL_IP'])) {
            $ip = $_SERVER['HTTP_X_REAL_IP'];
        } else if(isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
            $ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
        } else if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $arr = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $pos =  array_search('unknown',$arr);
            if(false !== $pos) unset($arr[$pos]);
            $ip   =  trim($arr[0]);
        }else if (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }else if (isset($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        
        return $ip;
    }
}

//获取域名
if(!function_exists('xtDomain')) {
    function xtDomain($isHost = null) {
        $host = $_SERVER['HTTP_HOST'];
        if($isHost === true) return $host;
        
        $protocol = '';
        if(isset($_SERVER['HTTP_CF_VISITOR']) && !empty($_SERVER['HTTP_CF_VISITOR'])) {
            $scheme = str_replace('\\', '', $_SERVER['HTTP_CF_VISITOR']);
            $scheme = json_decode($scheme, true);
            $protocol = $scheme['scheme'];
        } else {
            $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on' ? 'https' : 'http';
        }
        
        if($isHost === false) return $protocol;
        
        return $protocol.'://'.$host;
    }
}

//获取支付方式
if(!function_exists('xtPaymentCodes')) {
    function xtPaymentCodes($data = []) {
        if(empty($data)) return [];
        
        $sort = [];
        foreach($data as $v) {
            $v = is_object($v) ? ((Array) $v) : $v;
            $sort[] = intval($v['sort']);
        }
        sort($sort);
        
        $payment_types = [];
        
        foreach($sort as $v) {
            foreach($data as $vv) {
                $vv = is_object($vv) ? ((Array) $vv) : $vv;
                if($vv['sort'] == $v && !in_array($vv['code'], $payment_types)) {
                    $payment_types[] = $vv['code'];
                }
            }
        }
        return $payment_types;
    }
}

//js跳转
if(!function_exists('xtLocationReplace')) {
    function xtLocationReplace($url) {
        die('<script>window.location.replace("'.$url.'")</script>');
    }
}

//url解析成数组
if(!function_exists('xtParseQueryParams')) {
    function xtParseQueryParams($url, $flag = false) {
        $query = parse_url($url)['query'];
        
        if($flag === true) return $query;
        
        $and = explode('&', $query);
        $params = [];
        foreach($and as $v) {
            $tmp = explode('=', $v);
            $params[$tmp[0]] = $tmp[1];
        }
        
        return $params;
    }
}

//更改订单号
if(!function_exists('xtChangeOrderNumber')) {
    function xtChangeOrderNumber($orderId, $order) {
        $newOrderId = $order->get_meta('_new_order_number');
        return $newOrderId ? $newOrderId : $orderId;
    }
}

//创建wp订单
if(!function_exists('xtCreateOrder')) {
    function xtCreateOrder($data, $flag = true) {
        global $wpdb;
        if(!$data) return false;
        
        $wpdb->query('START TRANSACTION');
        try {
            unset($data['shipping']['email']);
            unset($data['shipping']['phone']);
            
            $order = wc_create_order();
            $order->set_address($data['billing'], 'billing');
            $order->set_address($data['shipping'], 'shipping');
            $order->set_customer_ip_address($data['ip']);
            $order->set_transaction_id($data['payment_id']);
            $order->set_payment_method($data['payment_name']);
            $order->set_status('completed');
            $order->update_meta_data('_new_order_number', $data['order_id']);
            $order->update_meta_data('_wc_order_attribution_utm_source', '('.$data['origin']['source'].')');
            $order->update_meta_data('_wc_order_attribution_source_type', $data['origin']['type']);
            
            if($flag === true) {
                $goodsId = xtCreateGoods($data, (new \xt\multi\ProductsCsv())->randGoods());
                if(empty($goodsId)) throw new \Exception('create goods failed');
                
                $product = wc_get_product($goodsId);
                $order->add_product($product, 1);
                $order->calculate_totals();
            } else {
                $order->set_total($data['total']);
            }
            
            $result = $order->save();
            if(empty($result)) throw new \Exception('create order failed');
            
            $wpdb->query('COMMIT');
            return $order->get_id();
        } catch(\Exception $e) {
            $wpdb->query('ROLLBACK');
            return false;
        }
        return false;
    }
}

//创建新商品
if(!function_exists('xtCreateGoods')) {
    function xtCreateGoods($data, $product = []) {
        if(!empty($product)) {
            $newGoods = [
                'post_title' => $product['name'],
                'post_author' => 1,
                'post_content' => $product['desc'],
                'post_status' => 'publish',
                'post_name' => $product['name'],
                'post_type' => 'product',
                '_visibility'       => 'visible',
                '_stock_status'     => 'instock',
            ];
            
            $goodsId = wp_insert_post($newGoods);
            if(!$goodsId) return false;
            
            set_post_thumbnail($goodsId, $product['image']);
            wp_set_post_terms($goodsId, $product['category'], 'product_cat'); 
            update_post_meta($goodsId, '_sku', xtGuid());
            update_post_meta($goodsId, '_price', $data['total']);
            update_post_meta($goodsId, '_stock', rand(100, 300));
            update_post_meta($goodsId, '_manage_stock', 'yes'); 
            
            return $goodsId;
        }
        
        $goods = xtRandGoods();
        if(!$goods) return false;
        
        $newGoods = [
            'post_title' => $goods->post_title,
            'post_author' => 1,
            'post_content' => $goods->post_content,
            'post_status' => 'publish',
            'post_name' => $goods->post_name,
            'post_type' => 'product',
            '_visibility'       => 'visible',
            '_stock_status'     => 'instock',
        ];
        
        $goodsId = wp_insert_post($newGoods);
        if(!$goodsId) return false;
            
        $imageId = xtGoodsImage($goods->ID);
        set_post_thumbnail($goodsId, $imageId);
        wp_set_post_terms($goodsId, xtGoodsCategory($goods->ID), 'product_cat'); 
        
        $oldGoods = wc_get_product($goods->ID);
        $attributes = $oldGoods->get_attributes();
        
        $attr = [];
        foreach($attributes as $attribute) {
            $attribute_name = $attribute->get_name();
            $attribute_options = $attribute->get_options();
            $current_value = $oldGoods->get_attribute($attribute_name);
            $real_value = isset($attribute_options[$current_value]) ? $attribute_options[$current_value] : $current_value;
            $attr[$attribute_name] = $real_value;
        }
        
        if(count($attr)) {
            update_post_meta($goodsId, '_sku', xtGuid());
            wp_set_object_terms($goodsId, 'variable', 'product_type');
            
            $attributes = [];
            foreach($attr as $key => $a) {
                $attributes[$key] = [
                    'name' =>  $key,
                    'value' => $a,
                    'is_visible'   => false, 
                    'is_variation' => true, 
                    'is_taxonomy'  => false, 
                ];
                update_post_meta($goodsId, 'attribute_' . $key, $a);
            }
            
            foreach ( $attributes as $attribute ) {
                $attribute_id = wc_create_attribute($attribute);
                $product_attributes[ $attribute['name']] = array(
                    'id'         => $attribute_id,
                    'name'       => $attribute['name'],
                    'value' => $attribute['value'],
                    'is_visible' => $attribute['is_visible'],
                    'is_variation' => $attribute['is_variation'],
                    'is_taxonomy' => $attribute['is_taxonomy'],
                );
            }
            update_post_meta($goodsId, '_product_attributes', $product_attributes);
           
            $variation = new WC_Product_Variation();
            $variation->set_parent_id($goodsId);
            $variation->set_regular_price($data['total']);
            $variation->set_stock_quantity(rand(100, 300));
            $variation->set_manage_stock(true);
            $variation->set_sku(xtGuid());
            $variation->set_stock_status('instock');
            $variation->set_image_id($imageId);
            foreach($attr as $key => $a) {
                $variation->add_meta_data('attribute_' . $key, $a, true);
            }
            $variation->save();
            $goodsId = $variation->get_id();
        } else {
            update_post_meta($goodsId, '_sku', xtGuid());
            update_post_meta($goodsId, '_price', $data['total']);
            update_post_meta($goodsId, '_stock', rand(100, 300));
            update_post_meta($goodsId, '_manage_stock', 'yes'); 
        }
        if(!$goodsId) return false;
        
        return $goodsId;
    }
}

//生成随机商品
if(!function_exists('xtRandGoods')) {
    function xtRandGoods() {
        $query = [
            'post_type' => 'product',
            'posts_per_page' => 1,
            'orderby' => 'rand'
        ];
        
        try {
            $products = get_posts($query);
            if($products) return $products[0];
            
        } catch(\Exception $e) {
            return false;
        }
        return false;
    }
}

//生成商品图片
if(!function_exists('xtGoodsImage')) {
    function xtGoodsImage($goodsId, $flag = false) {
        $onlyOneImageId = null;
        $imageIds = get_post_meta($goodsId, '_product_image_gallery', true);
        if(!empty($imageIds)) {
            $imageIds = explode(',', $imageIds);
            $onlyOneImageId = $imageIds[rand(0, count($imageIds)-1)];
        } else {
            $onlyOneImageId = get_post_thumbnail_id($goodsId);
        }
        
        if($flag && $onlyOneImageId) {
            $url = wp_get_attachment_image_src($onlyOneImageId);
            return $url[0] ?? '';
        }
        return $onlyOneImageId ?? 0;
    }
}

//生成商品分类
if(!function_exists('xtGoodsCategory')) {
    function xtGoodsCategory($goodsId, $flag = false) {
        if(!$flag) return wp_get_post_terms($goodsId, 'product_cat', ['fields' => 'ids']) ?? [];
        
        $category = get_the_terms($goodsId, 'product_cat') ?? [];
        $names = [];
        foreach($category as $v) {
            $names[] = $v->name;
        }
        return $names;
    }
}

//生成规格编号
if(!function_exists('xtGuid')) {
    function xtGuid(){
        mt_srand((double)microtime()*10000);
        $charid = strtoupper(md5(uniqid(rand(), true)));
        $hyphen = chr(45);
        $uuid = substr($charid, 0, 8).$hyphen
    
            .substr($charid, 8, 4).$hyphen
    
            .substr($charid,12, 4).$hyphen
    
            .substr($charid,16, 4).$hyphen
    
            .substr($charid,20,12);
        return $uuid;
    }
}

//更新缓存订单
if(!function_exists('xtCacheOrder')) {
    function xtCacheOrder($arr = [], $order = null) {
        if(empty($arr)) return;
        
        if(!empty($order) && is_string($order)) $order = xtValidOrder($order);
        
        if(empty($order) || empty(get_object_vars($order))) return;
        
        if(!empty($order->status) && $order->status == 'completed') return;
        
        if(!empty($arr['status']) && !empty($order->status) && $arr['status'] == $order->status) return;
        
        $keys = array_keys($arr);
        foreach($keys as $k) {
            $order->{$k} = $arr[$k];
        }
        
        xtValidOrder($order->terminal_order_sn, $order);
    }
}

//初始化
if(!function_exists('xtInitFilter')) {
    function xtInitFilter() {
        //禁用发邮件
        add_filter('woocommerce_email_enabled_new_order', '__return_false'); 
        add_filter('woocommerce_email_enabled_cancelled_order', '__return_false'); 
        add_filter('woocommerce_email_enabled_failed_order', '__return_false'); 
        add_filter('woocommerce_email_enabled_customer_processing_order', '__return_false');
        add_filter('woocommerce_email_enabled_customer_refunded_order', '__return_false');
        add_filter('woocommerce_email_enabled_customer_completed_order', '__return_false');
        add_filter('woocommerce_email_enabled_customer_on_hold_order', '__return_false');
        add_filter('woocommerce_email_enabled_customer_invoice', '__return_false');
        add_filter('woocommerce_email_enabled_customer_note', '__return_false');
        add_filter('woocommerce_email_enabled_customer_reset_password', '__return_false');
        add_filter('woocommerce_email_enabled_customer_new_account', '__return_false');
        
        //订单号
        add_filter('woocommerce_order_number', 'xtChangeOrderNumber', 1, 2);
        
        //定时任务
        add_action('xtRemoveExpiredCache', 'xtRemoveExpiredCacheHandler');
        
        //代理接口
        xtTestProxy();
    }
}

//文件缓存
if(!function_exists('xtCache')) {
    function xtCache($key = '', $value = '', $expiry = 3600*24*15) {
        if(empty($key)) return ;
        
        $cache = \xt\multi\Cache::getInstance();
        
        if($value === null) return $cache->delete($key);
        
        if($value === '') return $cache->get($key);
        
        $expiry = $expiry === true ? xtLongTime() : $expiry;
        
        return $cache->set($key, $value, $expiry);
    }
}

//文件缓存累加
if(!function_exists('xtcacheAppend')) {
    function xtcacheAppend($key = '', $value = '', $expiry = '') {
        if(empty($key)) return ;
        $cache = \xt\multi\Cache::getInstance();
        
        $cache->append($key, $value, $expiry);
    }
}


//定时删除缓存文件
if(!function_exists('xtRemoveExpiredCacheHandler')) {
    function xtRemoveExpiredCacheHandler() {
        $cache = \xt\multi\Cache::getInstance();
        $cache->clearExpired();
    }
}

//缓存目录
if(!function_exists('xtCacheDir')) {
    function xtCacheDir() {
        return WP_CONTENT_DIR.'/cache/xt';
    }
}

//超长时间
if(!function_exists('xtLongTime')) {
    function xtLongTime() {
        $date = new \DateTime('+200 years');
        return $date->getTimestamp();
    }
}

//没有描述移除描述框
if(!function_exists('xtRemovePaymentDescBox')) {
    function xtRemovePaymentDescBox($paymentId = '') {
        if(empty($paymentId)) return;
        
        echo '<script>
            jQuery(function($){
                var box = $("div.payment_box.payment_method_'.$paymentId.'")
                if(box.find("iframe").length > 0) return
                
                box.remove()
            })
        </script>';
    }
}

//模式切换沙盒或生产
if(!function_exists('xtChangeMode')) {
    function xtChangeMode() {
        echo '<script>
            window.onload = function() {
                jQuery(function($) {
                    modeInit()
                    
                    $(".change-mode").change(function(){
                        modeInit()
                    })
                    
                    function modeInit() {
                        if($(".change-mode").val() == "test") {
                            $(".enabled-test").parent().parent().parent().removeClass("hidden")
                            $(".enabled-live").parent().parent().parent().addClass("hidden")
                        } else {
                            $(".enabled-test").parent().parent().parent().addClass("hidden")
                            $(".enabled-live").parent().parent().parent().removeClass("hidden")
                        }
                    }
                    
                    $(document).on("click", ".proxy-test", function() {
                        $.post(window.location.origin+"/wp-json/proxy/test", {name: $(this).attr("id")}, function(res) {
                            $(".proxy-result").text(res.msg);
                        });
                    })
                })
            }
        </script>';
    }
}

//用户设备信息
if(!function_exists('xtJsDeviceInfo')) {
    function xtJsDeviceInfo() {
        $script = <<<SCRIPT
            jQuery(function($) {
                let device = {
                    lang: lang(), 
                    sw: sw(),
                    sh: sh(),
                    cd: cd(),
                    zf: zf(),
                    os: os(),
                    br: br(),
                    zo: zo(),
                };
                
                $("#payment").after(`<input id="wc_order_attribution_device" name="wc_order_attribution_device" type="hidden">`);
            
                $("#wc_order_attribution_device").val(JSON.stringify(device));
                
                
                function lang() {
                    return navigator.language || navigator.userLanguage
                } 
                
                function sw() {
                    return window.screen.width
                }
                
                function sh() {
                    return window.screen.height
                }
                
                function cd() {
                    return window.screen.colorDepth
                }
                
                function zf() {
                    return new Date().getTimezoneOffset()
                }
                
                function zo() {
                    let zone = zf();
                    return -zone / 60
                }
                
                function os() {
                    let os = (navigator.appVersion.indexOf("Win") != -1) ? "Windows" :
                         (navigator.appVersion.indexOf("Mac") != -1) ? "Mac" :
                         (navigator.appVersion.indexOf("X11") != -1) ? "UNIX" :
                         (navigator.appVersion.indexOf("Linux") != -1) ? "Linux" : "Unknown";
                    return os
                }
                
                function br() {
                    var browser = "Unknown";
                    if (navigator.userAgent.indexOf("Chrome") > -1) {
                        browser = "Chrome"
                    } else if (navigator.userAgent.indexOf("Firefox") > -1) {
                        browser = "Firefox"
                    } else if (navigator.userAgent.indexOf("Safari") > -1) {
                        browser = "Safari"
                    } else if (navigator.userAgent.indexOf("MSIE") > -1 || navigator.userAgent.indexOf("Trident") > -1) {
                        browser = "Internet Explorer";
                    }
                    
                    return browser
                }
            })
SCRIPT;

        $script = str_replace("\n", ' ', $script);
        
        echo <<<SCRIPT
        <script>
            jQuery(function($){
                window.onload = function() {
                    var deviceId = $("#wc_order_attribution_device")
                 
                    if(!deviceId.length) eval('{$script}')
                }
            })
        </script>
SCRIPT;
    }
}

//获取woocommer默认支付icon
if(!function_exists('xtWooPaymentIcons')) {
    function xtWooPaymentIcons($ext = 'svg') {
        $icons = [
            [
                'name' => 'visa',
                'alt' => 'Visa'    
            ],
            [
                'name' => 'mastercard',
                'alt' => 'MasterCard'    
            ],
            [
                'name' => 'discover',
                'alt' => 'Discover'    
            ],
            [
                'name' => 'amex',
                'alt' => 'Amex'    
            ],
            [
                'name' => 'jcb',
                'alt' => 'JCB'    
            ],
        ];
        
        $icon = '';
        foreach($icons as $i) {
            $icon .= '<img src="'.WC_HTTPS::force_https_url( WC()->plugin_url().'/assets/images/icons/credit-cards/'.$i['name'].'.'.$ext ) . '" alt="'.$i['alt'].'" style="max-width: 50px;"/>';
        }
        
        return $icon;
    }
}

//显示链接路径
if(!function_exists('xtShowGatewayConfigHtml')) {
    function xtShowGatewayConfigHtml($webhookUrl = '', $iframeUrl = '', $key = 0) {
        $webhookHtml = '<div><b>Webhook Url: </b>'.$webhookUrl.'</div>';
        $iframeHtml = '<div><b>Iframe Url: </b>'.$iframeUrl.'</div>';
        
        $html = '';
        switch($key) {
            case 0:
                $html = $webhookHtml.$iframeHtml;
                break;
            case 1:
                $html = $webhookHtml;
                break;
            case 2:
                $html = $iframeHtml;
                break;
        }
       
        return $html;
    }
}

//缓存订单
if(!function_exists('xtValidOrder')) {
    function xtValidOrder($terminal_order_sn = '', $order = null) {
        if(empty($terminal_order_sn)) throw new \Exception('invalid order sn');
        
        $orderKey = 'order'.$terminal_order_sn;
        if($order === null) return xtCache($orderKey);
        
        xtCache($orderKey, $order);
    }
}

//缓存请求域名
if(!function_exists('xtValidBase')) {
    function xtValidBase($terminal_order_sn = '', $base = null) {
        if(empty($terminal_order_sn)) throw new \Exception('invalid order sn');
        
        $baseKey = 'base'.$terminal_order_sn;
        if($base === null) return xtCache($baseKey);
        
        xtCache($baseKey, $base);
    }
}

//缓存终端号
if(!function_exists('xtTerminalSn')) {
    function xtTerminalSn($terminal_order_sn = '', $real_order_sn = null) {
        if(empty($terminal_order_sn)) throw new \Exception('invalid order sn');
        
        $snKey = 'real_sn'.$terminal_order_sn;
        if($real_order_sn === null) return xtCache($snKey);
        
        xtCache($snKey, $real_order_sn);
    }
}


//缓存token
if(!function_exists('xtValidToken')) {
    function xtValidToken($token = null, $file = null, $encodeUrl = null) {
        if($token === null) {
            if(empty($encodeUrl)) throw new \Exception('invalid encode');
            
            $token = md5($encodeUrl.time());
            xtCache($token, $encodeUrl);
            
            if(!empty($file)) xtCache('path_'.$token, $file);
            
            return xtDomain().'/'.$token;
        }
        
        if($file === true) return xtCache('path_'.$token);
        
        return xtCache($token);
    }
}

//生成缓存查询链接
if(!function_exists('xtCallbackUrl')) {
    function xtCallbackUrl($terminal_order_sn = '', $className = '', $key = '') {
        return xtdomain()."?terminal_order_sn={$terminal_order_sn}&sign={$className}&query={$key}";
    }
}

//返回查询回调token
if(!function_exists('xtCallbackToken')) {
    function xtCallbackToken($callbackUrl = '') {
        $len = strripos($callbackUrl, '/');
        if($len === false) throw new \Exception('invalid callback url');
        
        return substr($callbackUrl, $len+1);
    }
}

//iframe html 
if(!function_exists('xtIframeHtml')) {
    function xtIframeHtml($iframeUrl = '', $paymentId = '') {
        echo '<iframe src="'.$iframeUrl.'" frameborder="0" allowtransparency="true" scrolling="no" id="'.$paymentId.'-iframe" allow="payment"></iframe>';
    }
}

//客户端指纹信息
if(!function_exists('xtDeviceHash')) {
    function xtDeviceHash($agent) {
        return strtoupper(md5(hash('sha256', json_encode($agent))));
    }
}

//uuid
if(!function_exists('xtAffiliateId')) {
    function xtAffiliateId() {
        $data = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
    
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
}

//测试代理页面
if(!function_exists('xtTestProxy')) {
    function xtTestProxy($name = false) {
        if($name === false) {
            add_action('rest_api_init', function() {
        	    register_rest_route('proxy', '/test', [
        	        'methods' => 'POST',
                    'callback' => function(\WP_REST_Request $request) {
                        try {
                            (new \xt\multi\ProxyTest($request['name']))->test();
                            xtSuccess('success');
                        } catch (\Exception $e) {
                            xtError($e->getMessage());
                        }
                    },
                    'permission_callback' => function() {
                        return true;
                    }
        	    ]);
        	});
        	
        	return;
        }
        
        if(is_string($name)) {
            return <<<HTML
                <span>代理信息保存后，测试代理才有效。</span>
                <span style="color: #043959; text-decoration: underline; cursor: pointer;" class="proxy-test" id="$name">测试代理</span>
                <span style="margin-left: 10px;" class="proxy-result"></span>
HTML;
        }
       
    }
}

//是否为结账页
if(!function_exists('xtIsCheckoutPage')) {
    function xtIsCheckoutPage($flag = true) {
        $uri = substr(xtRouter(true), 1);
		$router = explode('/', $uri);
		$router = array_filter($router, function($value) {
		    return !empty($value);
		});
		
		if(empty($router) || strpos($router[0], 'checkout') === false) return false;
		
		if($flag === true) return count($router) === 1;
		
		return true;
    }
}