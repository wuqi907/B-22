<?php

namespace xt\multi;

trait Base {
    
    public $baseDir;
    public $baseDirName;
    public $basePluginName;
    private $config;
    
    public function __construct($callFile = null) 
    {
        $callFile = $callFile ?: debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1)[0]['file'];
        
        if(($len = strpos($callFile, '/wp-content/plugins/')) === false) throw new \Exception('invalid plugin path');
    
        $path = substr($callFile, $len+20);
        if(strpos($path, '/') === false) throw new \Exception('invalid plugin dir');
        
        $path = explode('/', $path);
        $this->baseDirName = $path[0];
        $this->baseDir = substr($callFile, 0, $len+20).$path[0];
        
        if(!file_exists($configUrl = $this->baseDir.'/lib/config.php')) throw new \Exception('missing configure');
        
        $this->config = require $configUrl;
        if(empty($this->config['name'])) throw new \Exception('invalid plugin name');
        
        $this->basePluginName = $this->config['name'];
    }
    
    //控制文件
    public function config($name = '')
    {
        $config = $this->config;
        if(strpos($name, '.') !== false) {
            $arr = explode('.', str_replace(' ', '', $name));
            foreach($arr as $a) {
                if(empty($config[$a])) return '';
                
                $config = $config[$a];
            }
            
            return $config;
        }
        
        $keyArr = array_keys($config);
        if(in_array($name, $keyArr)) return $config[$name];
        
        return '';
    }
    
    //网关设置
    public function paymentSettings()
    {
        return get_option('woocommerce_'.$this->basePluginName.'_settings');
    }
    
    //加密
    public function encode($data = '')
    {   
        return @base64_encode(openssl_encrypt($data, 'aes-256-cbc', $this->config('openssl_key'), OPENSSL_RAW_DATA, $this->config('openssl_iv')));
    }
    
    //解密
    public function decode($data = '')
    {
        return @openssl_decrypt(base64_decode($data), 'aes-256-cbc', $this->config('openssl_key'), OPENSSL_RAW_DATA, $this->config('openssl_iv'));
    }
    
    //webhook url
    public function webhookUrl($isSave = null) 
    {
        $webhookName = $this->config('webhook');
        if(empty($webhookName)) return;
        
        $webhookUrl = xtDomain().$this->config('path').'/'.$webhookName;
        $urlKey = urlencode($webhookUrl);
        
        $pluginDir = xtCache($urlKey);
        if($isSave === true || empty($pluginDir)) xtCache($urlKey, $this->baseDir, true);
        
        if($isSave === false) return $pluginDir;
        
        return $webhookUrl;
    }
    
    //iframe url
    public function iframeUrl($isSave = null) 
    {
        $name = $this->config('iframe');
        if(empty($name)) return;
        
        $iframeUrl = xtDomain().$this->config('path').'/'.$name;
        $iframeKey = urlencode($iframeUrl);
        
        $pluginDir = xtCache($iframeKey);
        if($isSave === true || empty($pluginDir)) xtCache($iframeKey, $this->baseDir, true);
        
        if($isSave === false) return $pluginDir;
        
        return $iframeUrl;
    }
    
    //记录日志
    public function logs($data = 'test-log', $name = null) 
    {
        $dir = $this->baseDir.'/logs/'.date('Y-m-d');
  
        if(!is_dir($dir)) mkdir($dir, 0777, true);
        
        if(!is_string($data)) $data = json_encode($data);
        
        file_put_contents($dir.'/'.($name ? $name : 'logs').'.log', date('Y-m-d H:i:s').PHP_EOL.$data.PHP_EOL.PHP_EOL, FILE_APPEND | LOCK_EX);
    } 
    
    //队列任务
    public function task($taskData = [], $api = 'update') 
    {
        if(empty($api) || empty($taskData)) return;
        
        $base = xtValidBase($taskData['terminal_order_sn']);
        $taskData['api'] = empty($taskData['api']) ? $base.$this->config('api.'.$api) : $taskData['api'];
        $taskData['order_task'] = isset($taskData['order_task']) ? $taskData['order_task'] : false; 
        
        if(!as_next_scheduled_action('updateClientTask', [$taskData])) {
            $actionId = as_enqueue_async_action('updateClientTask', [$taskData]);
            if(empty($actionId)) (new Request())->post($taskData['api'], json_encode($taskData));
            
            return $actionId;
        }
    }
    
    //延时任务
    public function delayTask($taskData = []) 
    {
        if(empty($taskData)) return;
        
        if(!as_next_scheduled_action('updateClientTask', [$taskData])) {
            as_schedule_single_action(time() + $this->config('exp.task'), 'updateClientTask', [$taskData]);
        }
    }
    
    //定时删除缓存任务
    public function intervalRemoveExpiredCache() 
    {
        if(!as_next_scheduled_action('xtRemoveExpiredCache')) as_schedule_recurring_action(time(), $this->config('exp.interval'), 'xtRemoveExpiredCache');
    }
    
    //错误信息通知
    public function errorNotice($terminal_order_sn = '', $msg = '')
    {
        if(empty($terminal_order_sn)) return;
        
        $ref = xtMultiSn($terminal_order_sn);
        if(empty($ref->terminal)) return;
        
        $postData = [
            'order_id' => $ref->order_id,
            'terminal_order_sn' => $terminal_order_sn,
            'error_msg' => $msg,
        ];
        
        $this->task($postData);
    }
    
    //订单通知
    public function orderNotice($terminal_order_sn = '', $postData = [], $flag = false) 
    {
        if(empty($terminal_order_sn) || empty($postData)) throw new \Exception('invalid notice');
        
        $ref = xtMultiSn($terminal_order_sn);
        if(empty($ref->terminal)) return;
        
        if($flag === true) {
            $base = xtValidBase($terminal_order_sn);
            $res = (new Request())->post($base.$this->config('api.update'), json_encode($postData));
            if(empty($res) || $res->code != 200) throw new \Exception(empty($res) ? 'update order request failed' : json_encode($res));
            
            return $res->data->return_url;
        }
        
        $postData['terminal_order_sn'] = $terminal_order_sn;
        $this->task($postData);
    }
    
    //创建审核站订单
    public function buildOrder($orderInfo)
    {
        $orderInfo = (array) $orderInfo;
        $orderInfo['order_task'] = true;
        $orderInfo['payment_name'] = $this->basePluginName;
        
        $actionId = $this->task($orderInfo);
        if(empty($actionId)) return false;
        
        return ['action_id' => $actionId];
    }
    
    //插件激活创建缓存
    public function pluginActive() 
    {
        $this->webhookUrl();
        $this->iframeUrl();
        
        if(!(new ProductsCsv())->isCsvExists()) {
            $taskData = [
                'task_name' => 'productsCsv', 
                'action' =>'chunkProducts', 
                'data' => []
            ];
            
            $this->delayTask($taskData);
        }
    }
    
    //更新关键缓存
    public function updateUrlCache()
    {
        $this->webhookUrl(true);
        $this->iframeUrl(true);
    }
    
    //生成内嵌链接
    public function buildIframeUrl($paymentId = '', $terminal = 0, $ext = []) 
    {
        $total = WC()->cart->get_total('raw');
        $total = !is_numeric($total) ? (preg_match('/\d+\.\d+/', $total, $matches) ? $matches[0] : $total)  : $total;
        $currency = get_woocommerce_currency();
        $country = WC()->customer->get_billing_country();
        
        $query = [
            'timestamp' => time(),
            'total' => $total,
            'currency' => $currency,
            'country' => $country,
        ];
        
        if(!empty($ext) && is_array($ext)) $query = array_merge($query, $ext);
        
        $url = $this->iframeUrl().'?'.http_build_query($query);
        
        $ao = base64_encode(uniqid().date('s'));
        $url .= '&ao='.str_replace(['+', '/', '='], '', $ao);
        
        $token = $this->buildIframeToken($url, $terminal);
        
        $iframeUrl = $url.'&token='.$token;
        
        if($paymentId === true) return $iframeUrl;
        
        if(!empty($paymentId)) xtIframeHtml($iframeUrl, $paymentId);
        
        return $iframeUrl; 
    }
    
    //校验内嵌链接
    public function checkIframeUrl()
    {
        try {
            $url = xtDomain().xtRouter(true);
            if(strpos($url, '&') === false) throw new \Exception('invalid url');
            
            $len = strripos($url, '&');
            $checkUrl = substr($url, 0, $len);
            $tokenStr = substr($url, $len+1);
            $tokenEx = explode('=', $tokenStr);
            $token = $tokenEx[1];
            
            $aToken = $this->buildIframeToken($checkUrl, 0);
            if($aToken == $token) return 0;
            
            $bToken = $this->buildIframeToken($checkUrl, 1);
            if($bToken == $token) return 1;
            
            throw new \Exception('invalid token');
        } catch (\Exception $e) {
            return false;
        }
    }
    
    //生成内嵌token
    public function buildIframeToken($url = '', $terminal = 0)
    {
        return md5($url.$terminal.$this->config('jk'));
    }
    
    //显示配置链接
    public function gatewayConfigDesc($key = 0)
    {
        return xtShowGatewayConfigHtml($this->webhookUrl(), $this->iframeUrl(), $key);
    }
    
    //有效token
    public function validToken($token = null, $file = null, $encodeUrl = null) {
        if($token === null) {
            if(empty($encodeUrl)) throw new \Exception('invalid encode');
            
            $token = md5($encodeUrl.time());
            xtCache($token, $encodeUrl);
            
            if(!empty($file)) xtCache('path_'.$token, $file);
            
            return xtDomain().$this->config('path').'/'.$token;
        }
        
        if($file === true) return xtCache('path_'.$token);
        
        return xtCache($token);
    }
}


















