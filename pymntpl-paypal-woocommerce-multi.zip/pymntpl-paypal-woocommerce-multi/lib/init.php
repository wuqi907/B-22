<?php
require __DIR__ . '/vendor/autoload.php';

\xt\multi\Middleware::init();
$require = (new \xt\multi\Util())->config('require');

foreach($require as $file) {
    require_once(__DIR__.'/'.$file.'.php');
}