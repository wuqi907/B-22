<?php
/**
 * Plugin Name: Payment Plugins for PayPal WooCommerce Multi
 * Plugin URI: https://docs.paymentplugins.com/wc-paypal/config/
 * Description: Accept PayPal on your WooCommerce site.
 * Version: 1.2.0
 * Author: Payment Plugins, support@paymentplugins.com
 * Text Domain: pymntpl-paypal-woocommerce
 * Domain Path: /i18n/languages/
 * Tested up to: 6.5
 * Requires at least: 4.7
 * Requires PHP: 7.1
 * WC requires at least: 3.4
 * WC tested up to: 9.0
 */

defined( 'ABSPATH' ) || exit;

define( 'WC_PAYPAL_MAIN_FILE', __FILE__ );
define( 'WC_PAYPAL_PLUGIN_PATH', untrailingslashit( plugin_dir_path( __FILE__ ) ) );
define( 'WC_PAYPAL_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WC_PAYPAL_PLUGIN_ASSEET', WC_PAYPAL_PLUGIN_URL.'assets');
define( 'WC_PAYPAL_PLUGIN_SLUG', 'ppcp_api');

require_once dirname( __FILE__ ) . '/lib/init.php';
require_once dirname( __FILE__ ) . '/vendor/autoload.php';

\PaymentPlugins\WooCommerce\PPCP\PluginValidation::is_valid( function () {
	new \PaymentPlugins\WooCommerce\PPCP\Main( '1.0.48', __FILE__ );
	
	$util = new \xt\multi\Util();
	
	add_action('rest_api_init', function() use($util) {
	    $util->interfaceApi('paypalAuthInterface');
	});
	
	if(!has_action('updateClientTask')) add_action('updateClientTask', [(new \xt\multi\AsyncTask()), 'handlerUpdateClientTask']);
	
	if(!has_action('init', 'xtInitFilter')) add_action('init', 'xtInitFilter');

	if(!has_action('init', 'xtProcessValidRouter')) add_action('init', 'xtProcessValidRouter');
	
	add_action('init', [$util, 'intervalRemoveExpiredCache']);
	
	require_once(dirname(__DIR__).'/woocommerce/src/Blocks/Integrations/IntegrationInterface.php');
	require_once(dirname(__DIR__).'/woocommerce/src/Blocks/Payments/PaymentMethodTypeInterface.php');
	require_once(dirname(__DIR__).'/woocommerce/src/Blocks/Payments/Integrations/AbstractPaymentMethodType.php');
	
	$util->loadBlock('paypalAuthBlock');
});

register_activation_hook(__FILE__, function() {
    (new \xt\multi\Util())->pluginActive();
});