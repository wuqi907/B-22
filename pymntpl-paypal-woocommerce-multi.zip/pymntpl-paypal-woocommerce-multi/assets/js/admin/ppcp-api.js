jQuery(function() {
    let $ = jQuery
    $('.ppcp_api').last().remove()
})