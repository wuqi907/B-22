<?php

namespace PaymentPlugins\PPCP\FunnelKit\Upsell;

class PaymentGatewaysRegistry extends \PaymentPlugins\WooCommerce\PPCP\Registry\BaseRegistry {

	protected $registry_id = 'funnelkit_gateways';

}