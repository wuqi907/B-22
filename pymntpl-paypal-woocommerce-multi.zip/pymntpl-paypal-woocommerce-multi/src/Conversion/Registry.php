<?php

namespace PaymentPlugins\WooCommerce\PPCP\Conversion;

class Registry extends \PaymentPlugins\WooCommerce\PPCP\Registry\BaseRegistry {

	protected $registry_id = 'plugin_conversion';

}