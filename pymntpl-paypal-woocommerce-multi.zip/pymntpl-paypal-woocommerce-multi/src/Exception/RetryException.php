<?php

namespace PaymentPlugins\WooCommerce\PPCP\Exception;

class RetryException extends \Exception {

}